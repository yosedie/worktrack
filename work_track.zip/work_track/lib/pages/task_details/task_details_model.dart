import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'task_details_widget.dart' show TaskDetailsWidget;
import 'package:flutter/material.dart';

class TaskDetailsModel extends FlutterFlowModel<TaskDetailsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
