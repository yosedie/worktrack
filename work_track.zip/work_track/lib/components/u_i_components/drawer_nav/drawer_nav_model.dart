import '/flutter_flow/flutter_flow_util.dart';
import 'drawer_nav_widget.dart' show DrawerNavWidget;
import 'package:flutter/material.dart';

class DrawerNavModel extends FlutterFlowModel<DrawerNavWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
