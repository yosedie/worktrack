import '/flutter_flow/flutter_flow_util.dart';
import 'task_component_widget.dart' show TaskComponentWidget;
import 'package:flutter/material.dart';

class TaskComponentModel extends FlutterFlowModel<TaskComponentWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
