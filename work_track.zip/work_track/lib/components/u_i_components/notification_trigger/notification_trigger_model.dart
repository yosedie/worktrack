import '/flutter_flow/flutter_flow_util.dart';
import 'notification_trigger_widget.dart' show NotificationTriggerWidget;
import 'package:flutter/material.dart';

class NotificationTriggerModel
    extends FlutterFlowModel<NotificationTriggerWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
