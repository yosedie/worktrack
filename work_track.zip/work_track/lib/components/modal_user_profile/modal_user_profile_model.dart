import '/flutter_flow/flutter_flow_util.dart';
import 'modal_user_profile_widget.dart' show ModalUserProfileWidget;
import 'package:flutter/material.dart';

class ModalUserProfileModel extends FlutterFlowModel<ModalUserProfileWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
