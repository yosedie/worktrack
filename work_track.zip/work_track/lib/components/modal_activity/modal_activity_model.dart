import '/flutter_flow/flutter_flow_util.dart';
import 'modal_activity_widget.dart' show ModalActivityWidget;
import 'package:flutter/material.dart';

class ModalActivityModel extends FlutterFlowModel<ModalActivityWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
