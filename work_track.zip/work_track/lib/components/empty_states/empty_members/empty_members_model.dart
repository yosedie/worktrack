import '/flutter_flow/flutter_flow_util.dart';
import 'empty_members_widget.dart' show EmptyMembersWidget;
import 'package:flutter/material.dart';

class EmptyMembersModel extends FlutterFlowModel<EmptyMembersWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
