import '/flutter_flow/flutter_flow_util.dart';
import 'empty_projects_widget.dart' show EmptyProjectsWidget;
import 'package:flutter/material.dart';

class EmptyProjectsModel extends FlutterFlowModel<EmptyProjectsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
