import '/flutter_flow/flutter_flow_util.dart';
import 'empty_notifications_widget.dart' show EmptyNotificationsWidget;
import 'package:flutter/material.dart';

class EmptyNotificationsModel
    extends FlutterFlowModel<EmptyNotificationsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
