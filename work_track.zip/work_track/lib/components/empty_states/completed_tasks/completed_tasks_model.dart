import '/flutter_flow/flutter_flow_util.dart';
import 'completed_tasks_widget.dart' show CompletedTasksWidget;
import 'package:flutter/material.dart';

class CompletedTasksModel extends FlutterFlowModel<CompletedTasksWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
