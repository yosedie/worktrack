import '/flutter_flow/flutter_flow_util.dart';
import 'empty_tasks_widget.dart' show EmptyTasksWidget;
import 'package:flutter/material.dart';

class EmptyTasksModel extends FlutterFlowModel<EmptyTasksWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
