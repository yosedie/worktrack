package com.mycompany.entprojecttracker

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
